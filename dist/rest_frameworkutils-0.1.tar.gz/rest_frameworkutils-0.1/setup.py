from setuptools import setup

setup(
    name='rest_frameworkutils',
    version='0.1',
    packages=['utils'],
    url='https://github.com/Ivy-1996/rest_framework-utils',
    license='',
    author='ivy',
    author_email='919624032@qq.com',
    description='rest_framework utils '
)
