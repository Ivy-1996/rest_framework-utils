class OssOssStroageSaveFailError(Exception):
    pass
